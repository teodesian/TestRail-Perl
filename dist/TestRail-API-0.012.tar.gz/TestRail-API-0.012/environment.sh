echo "export TESTRAIL_API_URL=\"http://testrail.local/\""
echo "export TESTRAIL_USER=\"doge@teodesian.net\""
echo "export TESTRAIL_PASSWORD=\"kf39bsd\""
